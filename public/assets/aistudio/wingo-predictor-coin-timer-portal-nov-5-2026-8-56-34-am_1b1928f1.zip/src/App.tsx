/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export default function App() {
  return (
    <div className="w-screen h-screen m-0 p-0 overflow-hidden bg-slate-900">
      <iframe
        src="/assets/aistudio/index__1__e48c5e9d.html"
        className="w-full h-full border-0 block"
        title="WinGo 1M Predictor & Coin Timer Portal"
        allow="clipboard-read; clipboard-write; fullscreen"
      />
    </div>
  );
}
